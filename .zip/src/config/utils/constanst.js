export const ObjConstanst = {
    URL_IMAGENPORDEFECTO:{
        URL: '../../assets/imagen-no-disponible.png'
    },
    IP_USUARIOS: 'http://127.0.0.1:4000/api/',
    IP_CULTURE: 'http://127.0.0.1:4001/api/',
    IP_PARTICIPANTES: 'http://127.0.0.1:4002/api/',
}