import { Col, Row } from 'antd';
import React from 'react'

import {
    Segment,
    Modal,
    Button,
    Header,
    Grid,
    Form,
    Input,
    Checkbox,
    Icon,
    Pagination,
    Divider,
    Select,
    Dropdown as DropdownSemantic,
    Breadcrumb,
    GridColumn,
} from "semantic-ui-react";

export const ModalVerificar = ({ openModal, setOpenModal }) => {
    return (
        <Modal open={openModal} size="large">
            <Row>
                <Col span={24}>
                    <Header
                        className="font-size-14px font-color-1B1C1D font-weight-600 font-family-Montserrat-SemiBold"
                    >
                        Verificación de propuestas
                    </Header>
                </Col>
            </Row>
        </Modal>
    )
}
