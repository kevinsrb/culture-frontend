import React from 'react';

import { Route, BrowserRouter as Router } from "react-router-dom";
// RUTAS
import Navbar from "../components/NavBar";