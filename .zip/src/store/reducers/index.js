import { combineReducers } from 'redux'
//import { authReducer } from '../reducers/authReducer'
//import { notesReducer } from '../reducers/notesReducer';
//import { uiReducer } from '../reducers/uiReducers';

export default combineReducers(
    {
        combineReducers
    }
)
