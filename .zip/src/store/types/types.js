// export const USER_TOKEN = 'USER_TOKEN';

export const types = {
    login: '[Auth] Login',
    logout: '[Auth] Logout',

    USER_TOKEN: '[User] User Token',

    idConvocatoria: '[Cvt] id convocatoria',
    edicion: '[Cvt] edicion',
    eliminar: '[Cvt] eliminar',

    idParticipante: '[Prt] id participante',
    documentos_convocatoria: '[Prt] documentos convocatoria'
}
